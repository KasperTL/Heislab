#pragma once
#include "elevatorFSM.h"
#include "../source/driver/elevio.h"
#include <stdio.h>



void startup_sequence(Elevator *anElevator);